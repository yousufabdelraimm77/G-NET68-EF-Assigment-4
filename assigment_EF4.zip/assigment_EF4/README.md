# National Bank Management System (EF Core Code-First)

Session 04 assignment - Eager Loading & Interactive Menu.
Console app, EF Core 8, SQL Server.

## How to run

1. Open `NationalBank/Data/BankDbContext.cs` and check the connection string
   (default: `Server=.;Database=NationalBankDb;Trusted_Connection=True;TrustServerCertificate=True`).
2. Install the EF tool once (if you don't have it): `dotnet tool install --global dotnet-ef`
3. From the `NationalBank` folder:

```bash
# Part 01 - create the database from the model (seed line is still commented in OnModelCreating)
dotnet ef migrations add InitialCreate
dotnet ef database update

# Part 02 - seeding
#   a) open Data/BankDbContext.cs and un-comment:  modelBuilder.Seed();
#   b) then:
dotnet ef migrations add SeedData
dotnet ef database update

# Part 03 - run the menu
dotnet run
```

(Package Manager Console equivalents: `Add-Migration InitialCreate`, `Update-Database`, `Add-Migration SeedData`, `Update-Database`.)

## Model decisions (from the ER diagram)

| Relationship | How it is mapped |
|---|---|
| Branch 1 : 1 Manager | `Branch.ManagerId` is a required, unique FK (Restrict delete) |
| Branch 1 : M Account | `Account.BranchCode` FK (Restrict delete) |
| Account 1 : M Transaction | `Transaction.AccountNumber` FK (Restrict - money history is never deleted silently) |
| Customer M : M Account ("Have") | join entity `CustomerAccount`, composite key `(CustomerId, AccountNumber)`; it carries `OwnershipType`, `OwnershipStartDate`, `AccountStatus` because the diagram puts them on the relationship |

* All enums are saved as text (`HasConversion<string>()`).
* Money columns are `decimal(18,2)`, dates are `date`, `Customer.NationalId` and `Email` are unique.
* Check constraints: account balance >= 0, transaction amount > 0.
* Seeded: 3 managers, 3 branches (required) + 2 customers, 2 accounts and their links, so option 5 looks like the sample output and the next new customer gets Id 3.

## Menu behaviour worth knowing

* **Option 2** - a new account must start with a `Primary` owner. To make a joint account, use the same account number again with role `CoHolder` for another customer.
* **Option 4** - deletes the `CustomerAccount` row. If that was the last owner the account is removed too, unless it already has transactions (then it is kept for the records). If the Primary leaves and co-holders remain, the oldest co-holder becomes Primary.
* **Option 5** - uses eager loading: `Include(CustomerAccounts).ThenInclude(Account).ThenInclude(Branch)`.
* Bad input never crashes the app; every action ends with "Press any key to return to the menu...".
