using System.Text;
using Microsoft.EntityFrameworkCore;
using NationalBank.Data;
using NationalBank.UI;

Console.OutputEncoding = Encoding.UTF8;

using var db = new BankDbContext();

var running = true;
while (running)
{
    Console.Clear();
    PrintMenu();

    var choice = (Console.ReadLine() ?? "").Trim();
    Console.WriteLine();

    switch (choice)
    {
        case "1": Execute(() => MenuActions.AddCustomer(db)); break;
        case "2": Execute(() => MenuActions.OpenAccount(db)); break;
        case "3": Execute(() => MenuActions.UpdateAccountStatus(db)); break;
        case "4": Execute(() => MenuActions.RemoveAccountFromCustomer(db)); break;
        case "5": Execute(() => MenuActions.ListCustomers(db)); break;
        case "0": running = false; break;
        default:
            ConsoleInput.Error("Invalid choice. Please type a number from the menu.");
            ConsoleInput.Pause();
            break;
    }
}

db.Database.CloseConnection();
Console.WriteLine("Connection closed. Goodbye!");

// ---------------------------------------------------------------------

static void PrintMenu()
{
    Console.WriteLine("========================================");
    Console.WriteLine("    National Bank - Management");
    Console.WriteLine("========================================");
    Console.WriteLine("  1) Add a new Customer");
    Console.WriteLine("  2) Open a new Account for a Customer");
    Console.WriteLine("  3) Update Account Status (Active / Closed)");
    Console.WriteLine("  4) Remove an Account from a Customer");
    Console.WriteLine("  5) List all Customers (with accounts)");
    Console.WriteLine("  0) Exit");
    Console.WriteLine("----------------------------------------");
    Console.Write("  Enter choice: ");
}

// Runs one menu action. Whatever goes wrong, the app shows a friendly message and keeps going.
void Execute(Action action)
{
    try
    {
        action();
    }
    catch (DbUpdateException ex)
    {
        ConsoleInput.Error($"The database refused the change: {ex.InnerException?.Message ?? ex.Message}");
    }
    catch (Exception ex)
    {
        ConsoleInput.Error($"Something went wrong: {ex.Message}");
    }
    finally
    {
        // throw away anything half-done so the next operation starts clean
        db.ChangeTracker.Clear();
        ConsoleInput.Pause();
    }
}
