namespace NationalBank.Models;

public class Manager
{
    public int Id { get; set; }
    public string FullName { get; set; } = null!;
    public string Email { get; set; } = null!;
    public string PhoneNumber { get; set; } = null!;
    public DateOnly HireDate { get; set; }

    // 1 : 1  (a manager manages exactly one branch)
    public Branch? Branch { get; set; }
}
