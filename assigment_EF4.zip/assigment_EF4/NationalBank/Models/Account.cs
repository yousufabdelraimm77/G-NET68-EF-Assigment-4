using NationalBank.Models.Enums;

namespace NationalBank.Models;

public class Account
{
    public string AccountNumber { get; set; } = null!;  // PK (string, e.g. "2001-CUR")
    public AccountType AccountType { get; set; }
    public decimal CurrentBalance { get; set; }
    public DateOnly OpeningDate { get; set; }

    // Account belongs to one Branch (M : 1)
    public string BranchCode { get; set; } = null!;
    public Branch Branch { get; set; } = null!;

    // M : M with Customer through CustomerAccount
    public ICollection<CustomerAccount> CustomerAccounts { get; set; } = new List<CustomerAccount>();

    // 1 : M with Transaction
    public ICollection<Transaction> Transactions { get; set; } = new List<Transaction>();
}
