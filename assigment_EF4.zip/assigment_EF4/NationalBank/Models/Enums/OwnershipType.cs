namespace NationalBank.Models.Enums;

public enum OwnershipType
{
    Primary = 1,
    CoHolder = 2
}
