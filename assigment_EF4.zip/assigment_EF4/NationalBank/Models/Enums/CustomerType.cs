namespace NationalBank.Models.Enums;

public enum CustomerType
{
    Individual = 1,
    Business = 2
}
