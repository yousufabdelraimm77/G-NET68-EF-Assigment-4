namespace NationalBank.Models.Enums;

public enum AccountStatus
{
    Active = 1,
    Closed = 2
}
