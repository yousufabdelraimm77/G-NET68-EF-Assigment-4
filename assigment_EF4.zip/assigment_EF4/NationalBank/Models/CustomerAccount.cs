using NationalBank.Models.Enums;

namespace NationalBank.Models;

/// <summary>
/// Join entity for the "Have" relationship (Customer M : M Account).
/// The ER diagram puts OwnershipType, OwnershipStartDate and AccountStatus on the relationship,
/// so they are columns of this table.
/// </summary>
public class CustomerAccount
{
    public int CustomerId { get; set; }
    public Customer Customer { get; set; } = null!;

    public string AccountNumber { get; set; } = null!;
    public Account Account { get; set; } = null!;

    public OwnershipType OwnershipType { get; set; }
    public DateOnly OwnershipStartDate { get; set; }
    public AccountStatus AccountStatus { get; set; }
}
