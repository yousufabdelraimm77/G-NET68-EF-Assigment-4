using System.Globalization;
using System.Net.Mail;
using System.Text.RegularExpressions;

namespace NationalBank.UI;

/// <summary>Small helpers so the menu code stays readable and never crashes on bad input.</summary>
public static class ConsoleInput
{
    // ---------- output ----------
    public static void Header(string title)
    {
        Console.WriteLine($"--- {title} ---");
    }

    public static void Success(string message) => WriteColored(message, ConsoleColor.Green);
    public static void Error(string message) => WriteColored(message, ConsoleColor.Red);
    public static void Info(string message) => WriteColored(message, ConsoleColor.Cyan);

    private static void WriteColored(string message, ConsoleColor color)
    {
        Console.ForegroundColor = color;
        Console.WriteLine(message);
        Console.ResetColor();
    }

    public static void Pause()
    {
        Console.WriteLine();
        Console.WriteLine("Press any key to return to the menu...");
        Console.ReadKey(true);
    }

    // ---------- input ----------
    public static string ReadText(string label, int minLength, int maxLength)
    {
        while (true)
        {
            Console.Write($"{label,-14}: ");
            var text = (Console.ReadLine() ?? "").Trim();

            if (text.Length >= minLength && text.Length <= maxLength)
                return text;

            Error($"  Please enter between {minLength} and {maxLength} characters.");
        }
    }

    public static string ReadDigits(string label, int minLength, int maxLength)
    {
        while (true)
        {
            Console.Write($"{label,-14}: ");
            var text = (Console.ReadLine() ?? "").Trim();

            if (Regex.IsMatch(text, $@"^\d{{{minLength},{maxLength}}}$"))
                return text;

            Error($"  {label} must be digits only ({minLength}-{maxLength} digits).");
        }
    }

    public static string ReadPhone(string label)
    {
        while (true)
        {
            Console.Write($"{label,-14}: ");
            var text = (Console.ReadLine() ?? "").Trim();

            if (Regex.IsMatch(text, @"^\+?\d{7,15}$"))
                return text;

            Error("  Phone must contain 7-15 digits (an optional leading + is allowed).");
        }
    }

    public static string ReadEmail(string label)
    {
        while (true)
        {
            Console.Write($"{label,-14}: ");
            var text = (Console.ReadLine() ?? "").Trim();

            if (text.Length <= 150 && IsValidEmail(text))
                return text;

            Error("  That doesn't look like a valid email (example: name@mail.com).");
        }
    }

    private static bool IsValidEmail(string email)
    {
        if (string.IsNullOrWhiteSpace(email)) return false;
        try
        {
            var addr = new MailAddress(email);
            return addr.Address == email && addr.Host.Contains('.');
        }
        catch (FormatException)
        {
            return false;
        }
    }

    public static DateOnly ReadDate(string label)
    {
        while (true)
        {
            Console.Write($"{label,-14}: (yyyy-MM-dd) ");
            var text = (Console.ReadLine() ?? "").Trim();

            if (!DateOnly.TryParseExact(text, "yyyy-MM-dd", CultureInfo.InvariantCulture,
                    DateTimeStyles.None, out var date))
            {
                Error("  Invalid date. Use the format yyyy-MM-dd, for example 2000-01-25.");
                continue;
            }

            if (date > DateOnly.FromDateTime(DateTime.Today) || date.Year < 1900)
            {
                Error("  The date must be between 1900 and today.");
                continue;
            }

            return date;
        }
    }

    public static int ReadPositiveInt(string label)
    {
        while (true)
        {
            Console.Write($"{label,-14}: ");
            var text = (Console.ReadLine() ?? "").Trim();

            if (int.TryParse(text, out var value) && value > 0)
                return value;

            Error("  Please enter a valid whole number greater than 0.");
        }
    }

    public static string ReadAccountNumber(string label)
    {
        while (true)
        {
            Console.Write($"{label,-14}: ");
            var text = (Console.ReadLine() ?? "").Trim().ToUpperInvariant();

            if (Regex.IsMatch(text, @"^[A-Z0-9\-]{4,20}$"))
                return text;

            Error("  Account number: 4-20 characters, letters / digits / hyphen only.");
        }
    }

    public static string ReadBranchCode(string label)
    {
        while (true)
        {
            Console.Write($"{label,-14}: ");
            var text = (Console.ReadLine() ?? "").Trim().ToUpperInvariant();

            if (Regex.IsMatch(text, @"^[A-Z0-9\-]{2,10}$"))
                return text;

            Error("  Branch code: 2-10 characters, letters / digits / hyphen only (e.g. CAI-01).");
        }
    }

    /// <summary>Prints a numbered list and returns the chosen number (1-based).</summary>
    public static int ReadChoice(string title, params string[] options)
    {
        Console.WriteLine($"{title}:");
        for (var i = 0; i < options.Length; i++)
            Console.WriteLine($"    {i + 1}) {options[i]}");

        while (true)
        {
            Console.Write("  Choice: ");
            var text = (Console.ReadLine() ?? "").Trim();

            if (int.TryParse(text, out var choice) && choice >= 1 && choice <= options.Length)
                return choice;

            Error($"  Please enter a number between 1 and {options.Length}.");
        }
    }
}
