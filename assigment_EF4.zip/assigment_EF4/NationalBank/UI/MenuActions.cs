using System.Globalization;
using Microsoft.EntityFrameworkCore;
using NationalBank.Data;
using NationalBank.Models;
using NationalBank.Models.Enums;

namespace NationalBank.UI;

public static class MenuActions
{
    // =====================================================================
    // 1) Add a new customer
    // =====================================================================
    public static void AddCustomer(BankDbContext db)
    {
        ConsoleInput.Header("Add New Customer");

        var fullName = ConsoleInput.ReadText("Full Name", 3, 100);

        var nationalId = ConsoleInput.ReadDigits("National ID", 10, 14);
        if (db.Customers.Any(c => c.NationalId == nationalId))
        {
            ConsoleInput.Error("A customer with this National ID already exists.");
            return;
        }

        var dateOfBirth = ConsoleInput.ReadDate("Date of Birth");

        var email = ConsoleInput.ReadEmail("Email");
        if (db.Customers.Any(c => c.Email == email))
        {
            ConsoleInput.Error("A customer with this email already exists.");
            return;
        }

        var phone = ConsoleInput.ReadPhone("Phone");
        var address = ConsoleInput.ReadText("Address", 5, 250);
        var type = (CustomerType)ConsoleInput.ReadChoice("Customer Type", "Individual", "Business");

        var customer = new Customer
        {
            FullName = fullName,
            NationalId = nationalId,
            DateOfBirth = dateOfBirth,
            Email = email,
            PhoneNumber = phone,
            Address = address,
            CustomerType = type
        };

        db.Customers.Add(customer);
        db.SaveChanges();

        Console.WriteLine();
        ConsoleInput.Success($"Customer created successfully. CustomerId = {customer.Id}");
    }

    // =====================================================================
    // 2) Open a new account for a customer
    // =====================================================================
    public static void OpenAccount(BankDbContext db)
    {
        ConsoleInput.Header("Open New Account");

        var accountNumber = ConsoleInput.ReadAccountNumber("Account Number");
        var accountType = (AccountType)ConsoleInput.ReadChoice("Account Type", "Savings", "Current", "Business");
        var branchCode = ConsoleInput.ReadBranchCode("Branch Code");
        var customerId = ConsoleInput.ReadPositiveInt("Customer Id");
        var role = (OwnershipType)ConsoleInput.ReadChoice("Ownership Role", "Primary", "CoHolder");

        ConsoleInput.Info($"Validating branch '{branchCode}' and customer #{customerId}...");

        var branch = db.Branches.FirstOrDefault(b => b.Code == branchCode);
        if (branch == null)
        {
            ConsoleInput.Error($"Branch '{branchCode}' does not exist. Account was not created.");
            return;
        }

        var customer = db.Customers.FirstOrDefault(c => c.Id == customerId);
        if (customer == null)
        {
            ConsoleInput.Error($"Customer #{customerId} does not exist. Account was not created.");
            return;
        }

        var account = db.Accounts.FirstOrDefault(a => a.AccountNumber == accountNumber);

        if (account == null)
        {
            // brand new account -> the first owner has to be the Primary owner
            if (role == OwnershipType.CoHolder)
            {
                ConsoleInput.Error($"Account '{accountNumber}' doesn't exist yet, so its first owner must be Primary.");
                return;
            }

            account = new Account
            {
                AccountNumber = accountNumber,
                AccountType = accountType,
                CurrentBalance = 0m,
                OpeningDate = DateOnly.FromDateTime(DateTime.Today),
                BranchCode = branch.Code
            };
            db.Accounts.Add(account);
        }
        else
        {
            // joint account: the account already exists, so we only add a co-holder link
            if (role == OwnershipType.Primary)
            {
                ConsoleInput.Error($"Account '{accountNumber}' already exists. Use CoHolder to share it with another customer.");
                return;
            }

            if (!string.Equals(account.BranchCode, branch.Code, StringComparison.OrdinalIgnoreCase))
            {
                ConsoleInput.Error($"Account '{accountNumber}' belongs to branch '{account.BranchCode}', not '{branch.Code}'.");
                return;
            }

            if (db.CustomerAccounts.Any(ca => ca.CustomerId == customerId && ca.AccountNumber == accountNumber))
            {
                ConsoleInput.Error($"Customer #{customerId} is already linked to account '{accountNumber}'.");
                return;
            }
        }

        db.CustomerAccounts.Add(new CustomerAccount
        {
            CustomerId = customer.Id,
            AccountNumber = accountNumber,
            OwnershipType = role,
            OwnershipStartDate = DateOnly.FromDateTime(DateTime.Today),
            AccountStatus = AccountStatus.Active
        });

        db.SaveChanges();

        ConsoleInput.Success($"Account '{accountNumber}' created and linked to customer {customer.Id} as {role} owner.");
    }

    // =====================================================================
    // 3) Update account status
    // =====================================================================
    public static void UpdateAccountStatus(BankDbContext db)
    {
        ConsoleInput.Header("Update Account Status");

        var accountNumber = ConsoleInput.ReadAccountNumber("Account Number");
        var customerId = ConsoleInput.ReadPositiveInt("Customer Id");

        var link = db.CustomerAccounts
            .FirstOrDefault(ca => ca.CustomerId == customerId && ca.AccountNumber == accountNumber);

        if (link == null)
        {
            ConsoleInput.Error($"Customer #{customerId} is not linked to account '{accountNumber}'.");
            return;
        }

        var newStatus = (AccountStatus)ConsoleInput.ReadChoice("New Status", "Active", "Closed");

        if (link.AccountStatus == newStatus)
        {
            ConsoleInput.Info($"The account is already {newStatus}. Nothing to change.");
            return;
        }

        link.AccountStatus = newStatus;
        db.SaveChanges();

        ConsoleInput.Success($"Status updated to {newStatus}.");
    }

    // =====================================================================
    // 4) Remove an account from a customer
    // =====================================================================
    public static void RemoveAccountFromCustomer(BankDbContext db)
    {
        ConsoleInput.Header("Remove Account From Customer");

        var accountNumber = ConsoleInput.ReadAccountNumber("Account Number");
        var customerId = ConsoleInput.ReadPositiveInt("Customer Id");

        var link = db.CustomerAccounts
            .FirstOrDefault(ca => ca.CustomerId == customerId && ca.AccountNumber == accountNumber);

        if (link == null)
        {
            ConsoleInput.Error($"Customer #{customerId} is not linked to account '{accountNumber}'.");
            return;
        }

        db.CustomerAccounts.Remove(link);

        // who else still owns this account?
        var otherOwners = db.CustomerAccounts
            .Where(ca => ca.AccountNumber == accountNumber && ca.CustomerId != customerId)
            .OrderBy(ca => ca.OwnershipStartDate)
            .ToList();

        string? extraMessage = null;

        if (otherOwners.Count == 0)
        {
            // last owner leaving -> the account has no owner anymore
            var hasTransactions = db.Transactions.Any(t => t.AccountNumber == accountNumber);

            if (hasTransactions)
            {
                // we must keep the history of the money movements, so the account itself stays
                extraMessage = $"That was the last owner, but account '{accountNumber}' has transactions, so it was kept for the records.";
            }
            else
            {
                var account = db.Accounts.First(a => a.AccountNumber == accountNumber);
                db.Accounts.Remove(account);
                extraMessage = $"That was the last owner - account '{accountNumber}' was also removed.";
            }
        }
        else if (link.OwnershipType == OwnershipType.Primary &&
                 otherOwners.All(o => o.OwnershipType != OwnershipType.Primary))
        {
            // the primary owner left but co-holders remain -> promote the oldest co-holder
            var newPrimary = otherOwners[0];
            newPrimary.OwnershipType = OwnershipType.Primary;
            extraMessage = $"Customer #{newPrimary.CustomerId} was promoted to Primary owner of '{accountNumber}'.";
        }

        db.SaveChanges();

        Console.WriteLine();
        ConsoleInput.Success("  Ownership link deleted.");
        if (extraMessage != null)
            ConsoleInput.Info("      " + extraMessage);
    }

    // =====================================================================
    // 5) List all customers (eager loading)
    // =====================================================================
    public static void ListCustomers(BankDbContext db)
    {
        ConsoleInput.Header("All Customers");
        Console.WriteLine();

        // Eager loading: one query brings the customers, their CustomerAccount rows,
        // the account behind each row and that account's branch.
        var customers = db.Customers
            .Include(c => c.CustomerAccounts)
                .ThenInclude(ca => ca.Account)
                    .ThenInclude(a => a.Branch)
            .AsNoTracking()
            .OrderBy(c => c.Id)
            .ToList();

        if (customers.Count == 0)
        {
            ConsoleInput.Info("  (no customers yet)");
            return;
        }

        var inv = CultureInfo.InvariantCulture;

        foreach (var c in customers)
        {
            Console.WriteLine($"  #{c.Id} {c.FullName} ({c.CustomerType})");

            if (c.CustomerAccounts.Count == 0)
            {
                Console.WriteLine("      (no accounts)");
                continue;
            }

            foreach (var ca in c.CustomerAccounts.OrderBy(x => x.AccountNumber))
            {
                var a = ca.Account;
                var balance = a.CurrentBalance.ToString("N2", inv);

                Console.WriteLine(
                    $"      {a.AccountNumber,-10} {a.AccountType,-9} Balance: {balance,12}   " +
                    $"{ca.OwnershipType,-8} {ca.AccountStatus,-7} @ {a.Branch.Name}");
            }
        }
    }
}
