using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NationalBank.Models;

namespace NationalBank.Data.Configurations;

public class AccountConfiguration : IEntityTypeConfiguration<Account>
{
    public void Configure(EntityTypeBuilder<Account> builder)
    {
        builder.ToTable("Accounts", t =>
            t.HasCheckConstraint("CK_Accounts_CurrentBalance", "[CurrentBalance] >= 0"));

        builder.HasKey(a => a.AccountNumber);

        builder.Property(a => a.AccountNumber).HasMaxLength(20).ValueGeneratedNever();
        builder.Property(a => a.AccountType).HasConversion<string>().HasMaxLength(20);
        builder.Property(a => a.CurrentBalance).HasPrecision(18, 2);
        builder.Property(a => a.OpeningDate).HasColumnType("date");
        builder.Property(a => a.BranchCode).IsRequired().HasMaxLength(10);

        // Branch 1 : M Account
        builder.HasOne(a => a.Branch)
               .WithMany(b => b.Accounts)
               .HasForeignKey(a => a.BranchCode)
               .OnDelete(DeleteBehavior.Restrict);   // a branch with accounts can't be deleted
    }
}
