using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NationalBank.Models;

namespace NationalBank.Data.Configurations;

public class CustomerConfiguration : IEntityTypeConfiguration<Customer>
{
    public void Configure(EntityTypeBuilder<Customer> builder)
    {
        builder.HasKey(c => c.Id);

        builder.Property(c => c.FullName).IsRequired().HasMaxLength(100);
        builder.Property(c => c.NationalId).IsRequired().HasMaxLength(14);
        builder.Property(c => c.Email).IsRequired().HasMaxLength(150);
        builder.Property(c => c.PhoneNumber).IsRequired().HasMaxLength(20);
        builder.Property(c => c.Address).IsRequired().HasMaxLength(250);
        builder.Property(c => c.DateOfBirth).HasColumnType("date");

        // store the enum as text so the table is readable
        builder.Property(c => c.CustomerType).HasConversion<string>().HasMaxLength(20);

        builder.HasIndex(c => c.NationalId).IsUnique();
        builder.HasIndex(c => c.Email).IsUnique();
    }
}
