using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NationalBank.Models;

namespace NationalBank.Data.Configurations;

public class BranchConfiguration : IEntityTypeConfiguration<Branch>
{
    public void Configure(EntityTypeBuilder<Branch> builder)
    {
        builder.HasKey(b => b.Code);

        builder.Property(b => b.Code).HasMaxLength(10).ValueGeneratedNever();
        builder.Property(b => b.Name).IsRequired().HasMaxLength(100);
        builder.Property(b => b.Address).IsRequired().HasMaxLength(250);
        builder.Property(b => b.PhoneNumber).IsRequired().HasMaxLength(20);

        // Branch 1 : 1 Manager  -> unique FK on Branch.ManagerId
        builder.HasOne(b => b.Manager)
               .WithOne(m => m.Branch)
               .HasForeignKey<Branch>(b => b.ManagerId)
               .IsRequired()
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasIndex(b => b.ManagerId).IsUnique();
    }
}
