using Microsoft.EntityFrameworkCore;
using NationalBank.Models;

namespace NationalBank.Data;

public class BankDbContext : DbContext
{
    public DbSet<Branch> Branches => Set<Branch>();
    public DbSet<Manager> Managers => Set<Manager>();
    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<Account> Accounts => Set<Account>();
    public DbSet<CustomerAccount> CustomerAccounts => Set<CustomerAccount>();
    public DbSet<Transaction> Transactions => Set<Transaction>();

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
        {
            // Change the server name if you are not using a default local SQL Server instance
            // e.g. "Server=(localdb)\\MSSQLLocalDB;..."
            optionsBuilder.UseSqlServer(
                "Server=.;Database=NationalBankDb;Trusted_Connection=True;TrustServerCertificate=True");
        }
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(BankDbContext).Assembly);

        // STEP 2 (Part 02 - Seeding): keep this line commented while creating the first migration
        // (InitialCreate). Un-comment it afterwards and add the second migration (SeedData).
        // modelBuilder.Seed();
    }
}
