using Microsoft.EntityFrameworkCore;
using NationalBank.Models;
using NationalBank.Models.Enums;

namespace NationalBank.Data;

public static class SeedData
{
    public static void Seed(this ModelBuilder modelBuilder)
    {
        // ---- required by the assignment: Manager + Branch ----
        modelBuilder.Entity<Manager>().HasData(
            new Manager { Id = 1, FullName = "Khaled Mansour", Email = "khaled.mansour@nationalbank.com", PhoneNumber = "01001112233", HireDate = new DateOnly(2015, 3, 1) },
            new Manager { Id = 2, FullName = "Hoda Samir",     Email = "hoda.samir@nationalbank.com",     PhoneNumber = "01002223344", HireDate = new DateOnly(2018, 7, 15) },
            new Manager { Id = 3, FullName = "Tamer Fathy",    Email = "tamer.fathy@nationalbank.com",    PhoneNumber = "01003334455", HireDate = new DateOnly(2020, 1, 10) }
        );

        modelBuilder.Entity<Branch>().HasData(
            new Branch { Code = "CAI-01", Name = "Cairo Main Branch", Address = "12 Tahrir Square, Cairo",      PhoneNumber = "0225700001", ManagerId = 1 },
            new Branch { Code = "ALX-01", Name = "Alexandria Branch", Address = "45 Corniche Road, Alexandria", PhoneNumber = "0335700002", ManagerId = 2 },
            new Branch { Code = "GIZ-01", Name = "Giza Branch",        Address = "8 Pyramids Road, Giza",        PhoneNumber = "0235700003", ManagerId = 3 }
        );

        // ---- extra sample data so option 5 has something to show (matches the sample output) ----
        modelBuilder.Entity<Customer>().HasData(
            new Customer { Id = 1, FullName = "Ahmed Ali",        NationalId = "29001011234567", DateOfBirth = new DateOnly(1990, 1, 1),  Email = "ahmed.ali@gmail.com",   PhoneNumber = "01011112222", Address = "5 Nile St, Cairo",         CustomerType = CustomerType.Individual },
            new Customer { Id = 2, FullName = "Nile Trading LLC", NationalId = "50012345678901", DateOfBirth = new DateOnly(2005, 5, 20), Email = "info@niletrading.com",   PhoneNumber = "01022223333", Address = "20 Port Said St, Alexandria", CustomerType = CustomerType.Business }
        );

        modelBuilder.Entity<Account>().HasData(
            new Account { AccountNumber = "2001-CUR", AccountType = AccountType.Current,  CurrentBalance = 15400m,  OpeningDate = new DateOnly(2022, 2, 1), BranchCode = "CAI-01" },
            new Account { AccountNumber = "3000-BUS", AccountType = AccountType.Business, CurrentBalance = 120000m, OpeningDate = new DateOnly(2021, 9, 5), BranchCode = "ALX-01" }
        );

        modelBuilder.Entity<CustomerAccount>().HasData(
            new CustomerAccount { CustomerId = 1, AccountNumber = "2001-CUR", OwnershipType = OwnershipType.Primary, OwnershipStartDate = new DateOnly(2022, 2, 1), AccountStatus = AccountStatus.Active },
            new CustomerAccount { CustomerId = 2, AccountNumber = "3000-BUS", OwnershipType = OwnershipType.Primary, OwnershipStartDate = new DateOnly(2021, 9, 5), AccountStatus = AccountStatus.Active }
        );
    }
}
